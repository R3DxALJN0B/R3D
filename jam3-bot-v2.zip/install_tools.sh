#!/bin/bash

echo "تحديث النظام..."
sudo apt update && sudo apt install -y git python3-pip

echo "تثبيت المتطلبات..."
pip3 install -r requirements.txt

echo "تثبيت Sherlock..."
git clone https://github.com/sherlock-project/sherlock.git
cd sherlock && pip3 install -r requirements.txt && cd ..

echo "تثبيت PhoneInfoga..."
git clone https://github.com/sundowndev/phoneinfoga.git
cd phoneinfoga && pip3 install -r requirements.txt && cd ..

echo "تثبيت theHarvester..."
git clone https://github.com/laramies/theHarvester.git
cd theHarvester && pip3 install -r requirements/base.txt && cd ..

echo "تثبيت Holehe..."
git clone https://github.com/megadose/holehe.git
cd holehe && pip3 install . && cd ..

echo "تثبيت Socialscan..."
git clone https://github.com/iojw/socialscan.git
cd socialscan && pip3 install . && cd ..

echo "تم تثبيت الأدوات بنجاح!"